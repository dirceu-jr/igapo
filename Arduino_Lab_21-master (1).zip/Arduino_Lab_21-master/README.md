# Arduino_Lab_21
Repositório para os códigos utilizados no Tutorial Arduino Lab 21.

-> A boblioteca para uso do sensor DHT22 pode ser baixada diretamente pela IDE do Arduino, pesquisando por DHT22 e escolhendo a biblioteca da Adafruit.

Site: easytromlabs.com
