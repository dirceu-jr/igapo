<?php
// Estabelece as credenciais para a conexão com o banco de dados
	define('HOST', 'localhost');
	define('USUARIO', 'id10241934_db_iot');
	define('SENHA', '123456');
	define('DB', 'id10241934_db_iot');

?>